<div class="app-footer">
    <div class="col-12 widget-content bg-premium-dark text-center rounded-top"
    style="bottom: 0; color: #fff; font-weight: bold;padding: 10px;">
    Developed by Surya || &nbsp; {{date('Y')}}
</div>
</div>
<!-- SlimScroll -->
<script src="{{ asset('assets/js/main.js') }}"></script>

<script>
    setTimeout(function () {
        $('.alert').fadeOut('slow');
    }, 5000); // <-- time in milliseconds
</script>
