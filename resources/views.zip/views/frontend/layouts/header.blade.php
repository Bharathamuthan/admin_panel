<section class="topbar">
	<div class="container">
		<div class="row">
			<p><i class="fa fa-phone"></i> 88 01851334234 || Email : <i class="fa fa-envelope"></i>
			riyad@w3xplorers.com</p>
		</div>
	</div>
</section>

