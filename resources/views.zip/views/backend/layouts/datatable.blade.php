<link href="{{ asset('/assets/datatables/css/dataTables.min.css') }}" rel="stylesheet"
      type="text/css"/>
<link href="{{ asset('/assets/datatables/css/dataTables.bootstrap4.min.css') }}" rel="stylesheet"
      type="text/css"/>


<script src="{{ asset('/assets/datatables/js/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('/assets/datatables/js/dataTables.bootstrap4.min.js') }}"></script>
<script src="{{ asset('/assets/datatables/js/dataTables.buttons.min.js') }}"></script>
<script src="{{ asset('/assets/datatables/js/buttons.bootstrap4.min.js') }}"></script>
<script src="{{ asset('/assets/datatables/js/jszip.min.js') }}"></script>
<script src="{{ asset('/assets/datatables/js/pdfmake.min.js') }}"></script>
<script src="{{ asset('/assets/datatables/js/vfs_fonts.js') }}"></script>
<script src="{{ asset('/assets/datatables/js/buttons.html5.min.js') }}"></script>
<script src="{{ asset('/assets/datatables/js/buttons.print.min.js') }}"></script>
<script src="{{ asset('/assets/datatables/js/buttons.colVis.min.js') }}"></script>
<script src="{{ asset('/assets/datatables/js/dataTables.select.min.js') }}"></script>

